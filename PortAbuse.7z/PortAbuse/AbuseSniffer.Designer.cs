﻿namespace PortAbuse
{
    partial class AbuseSniffer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AbuseSniffer));
            this.treeView = new System.Windows.Forms.TreeView();
            this.btnStart = new System.Windows.Forms.Button();
            this.cmbInterfaces = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.RemoteIP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.RemoteHost = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.RemCountry = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.заблокироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.разблокироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заблокироватьНа30СекундToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.входящиеНа30СекундToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.исходящиеНа30СекундToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BlockNewStrip = new System.Windows.Forms.ToolStripMenuItem();
            this.дополнительноToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ipcheck2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ipcheck3 = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьIPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьИндексToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.маркироватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.синийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.зеленыйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оранжевыйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.желтыйToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьМаркерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button1 = new System.Windows.Forms.Button();
            this.cTM = new System.Windows.Forms.CheckBox();
            this.cRem = new System.Windows.Forms.CheckBox();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(560, 197);
            this.treeView.TabIndex = 0;
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Location = new System.Drawing.Point(12, 522);
            this.btnStart.Name = "btnStart";
            this.btnStart.Padding = new System.Windows.Forms.Padding(28, 0, 0, 0);
            this.btnStart.Size = new System.Drawing.Size(91, 33);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "&Start";
            this.btnStart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // cmbInterfaces
            // 
            this.cmbInterfaces.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbInterfaces.BackColor = System.Drawing.Color.PaleTurquoise;
            this.cmbInterfaces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInterfaces.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbInterfaces.FormattingEnabled = true;
            this.cmbInterfaces.Location = new System.Drawing.Point(109, 529);
            this.cmbInterfaces.Name = "cmbInterfaces";
            this.cmbInterfaces.Size = new System.Drawing.Size(393, 21);
            this.cmbInterfaces.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 8);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(532, 21);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(550, 7);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(22, 21);
            this.button4.TabIndex = 9;
            this.button4.Text = "&r";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button4_MouseDown);
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.RemoteIP,
            this.RemoteHost,
            this.RemCountry});
            this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(560, 280);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.TabIndex = 10;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseDown);
            // 
            // RemoteIP
            // 
            this.RemoteIP.Text = "RemoteIP";
            this.RemoteIP.Width = 100;
            // 
            // RemoteHost
            // 
            this.RemoteHost.Text = "RemoteHost";
            this.RemoteHost.Width = 180;
            // 
            // RemCountry
            // 
            this.RemCountry.Text = "Country";
            this.RemCountry.Width = 250;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "_African Union(OAS).png");
            this.imageList1.Images.SetKeyName(1, "_Arab League.png");
            this.imageList1.Images.SetKeyName(2, "_ASEAN.png");
            this.imageList1.Images.SetKeyName(3, "_CARICOM.png");
            this.imageList1.Images.SetKeyName(4, "_CIS.png");
            this.imageList1.Images.SetKeyName(5, "_Commonwealth.png");
            this.imageList1.Images.SetKeyName(6, "_England.png");
            this.imageList1.Images.SetKeyName(7, "_European Union.png");
            this.imageList1.Images.SetKeyName(8, "_Islamic Conference.png");
            this.imageList1.Images.SetKeyName(9, "_Kosovo.png");
            this.imageList1.Images.SetKeyName(10, "_NATO.png");
            this.imageList1.Images.SetKeyName(11, "_Northern Cyprus.png");
            this.imageList1.Images.SetKeyName(12, "_Northern Ireland.png");
            this.imageList1.Images.SetKeyName(13, "_Olimpic Movement.png");
            this.imageList1.Images.SetKeyName(14, "_OPEC.png");
            this.imageList1.Images.SetKeyName(15, "_Red Cross.png");
            this.imageList1.Images.SetKeyName(16, "_Scotland.png");
            this.imageList1.Images.SetKeyName(17, "_Somaliland.png");
            this.imageList1.Images.SetKeyName(18, "_United Nations.png");
            this.imageList1.Images.SetKeyName(19, "_Wales.png");
            this.imageList1.Images.SetKeyName(20, "ad.png");
            this.imageList1.Images.SetKeyName(21, "ae.png");
            this.imageList1.Images.SetKeyName(22, "af.png");
            this.imageList1.Images.SetKeyName(23, "ag.png");
            this.imageList1.Images.SetKeyName(24, "ai.png");
            this.imageList1.Images.SetKeyName(25, "al.png");
            this.imageList1.Images.SetKeyName(26, "am.png");
            this.imageList1.Images.SetKeyName(27, "an.png");
            this.imageList1.Images.SetKeyName(28, "ao.png");
            this.imageList1.Images.SetKeyName(29, "aq.png");
            this.imageList1.Images.SetKeyName(30, "ar.png");
            this.imageList1.Images.SetKeyName(31, "as.png");
            this.imageList1.Images.SetKeyName(32, "at.png");
            this.imageList1.Images.SetKeyName(33, "au.png");
            this.imageList1.Images.SetKeyName(34, "aw.png");
            this.imageList1.Images.SetKeyName(35, "az.png");
            this.imageList1.Images.SetKeyName(36, "ba.png");
            this.imageList1.Images.SetKeyName(37, "bb.png");
            this.imageList1.Images.SetKeyName(38, "bd.png");
            this.imageList1.Images.SetKeyName(39, "be.png");
            this.imageList1.Images.SetKeyName(40, "bf.png");
            this.imageList1.Images.SetKeyName(41, "bg.png");
            this.imageList1.Images.SetKeyName(42, "bh.png");
            this.imageList1.Images.SetKeyName(43, "bi.png");
            this.imageList1.Images.SetKeyName(44, "bj.png");
            this.imageList1.Images.SetKeyName(45, "bm.png");
            this.imageList1.Images.SetKeyName(46, "bn.png");
            this.imageList1.Images.SetKeyName(47, "bo.png");
            this.imageList1.Images.SetKeyName(48, "br.png");
            this.imageList1.Images.SetKeyName(49, "bs.png");
            this.imageList1.Images.SetKeyName(50, "bt.png");
            this.imageList1.Images.SetKeyName(51, "bw.png");
            this.imageList1.Images.SetKeyName(52, "by.png");
            this.imageList1.Images.SetKeyName(53, "bz.png");
            this.imageList1.Images.SetKeyName(54, "ca.png");
            this.imageList1.Images.SetKeyName(55, "cd.png");
            this.imageList1.Images.SetKeyName(56, "cf.png");
            this.imageList1.Images.SetKeyName(57, "cg.png");
            this.imageList1.Images.SetKeyName(58, "ch.png");
            this.imageList1.Images.SetKeyName(59, "ci.png");
            this.imageList1.Images.SetKeyName(60, "ck.png");
            this.imageList1.Images.SetKeyName(61, "cl.png");
            this.imageList1.Images.SetKeyName(62, "cm.png");
            this.imageList1.Images.SetKeyName(63, "cn.png");
            this.imageList1.Images.SetKeyName(64, "co.png");
            this.imageList1.Images.SetKeyName(65, "cr.png");
            this.imageList1.Images.SetKeyName(66, "cu.png");
            this.imageList1.Images.SetKeyName(67, "cv.png");
            this.imageList1.Images.SetKeyName(68, "cy.png");
            this.imageList1.Images.SetKeyName(69, "cz.png");
            this.imageList1.Images.SetKeyName(70, "de.png");
            this.imageList1.Images.SetKeyName(71, "dj.png");
            this.imageList1.Images.SetKeyName(72, "dk.png");
            this.imageList1.Images.SetKeyName(73, "dm.png");
            this.imageList1.Images.SetKeyName(74, "do.png");
            this.imageList1.Images.SetKeyName(75, "dz.png");
            this.imageList1.Images.SetKeyName(76, "ec.png");
            this.imageList1.Images.SetKeyName(77, "ee.png");
            this.imageList1.Images.SetKeyName(78, "eg.png");
            this.imageList1.Images.SetKeyName(79, "eh.png");
            this.imageList1.Images.SetKeyName(80, "er.png");
            this.imageList1.Images.SetKeyName(81, "es.png");
            this.imageList1.Images.SetKeyName(82, "et.png");
            this.imageList1.Images.SetKeyName(83, "fi.png");
            this.imageList1.Images.SetKeyName(84, "fj.png");
            this.imageList1.Images.SetKeyName(85, "fm.png");
            this.imageList1.Images.SetKeyName(86, "fo.png");
            this.imageList1.Images.SetKeyName(87, "fr.png");
            this.imageList1.Images.SetKeyName(88, "ga.png");
            this.imageList1.Images.SetKeyName(89, "gb.png");
            this.imageList1.Images.SetKeyName(90, "gd.png");
            this.imageList1.Images.SetKeyName(91, "ge.png");
            this.imageList1.Images.SetKeyName(92, "gg.png");
            this.imageList1.Images.SetKeyName(93, "gh.png");
            this.imageList1.Images.SetKeyName(94, "gi.png");
            this.imageList1.Images.SetKeyName(95, "gl.png");
            this.imageList1.Images.SetKeyName(96, "gm.png");
            this.imageList1.Images.SetKeyName(97, "gn.png");
            this.imageList1.Images.SetKeyName(98, "gp.png");
            this.imageList1.Images.SetKeyName(99, "gq.png");
            this.imageList1.Images.SetKeyName(100, "gr.png");
            this.imageList1.Images.SetKeyName(101, "gt.png");
            this.imageList1.Images.SetKeyName(102, "gu.png");
            this.imageList1.Images.SetKeyName(103, "gw.png");
            this.imageList1.Images.SetKeyName(104, "gy.png");
            this.imageList1.Images.SetKeyName(105, "hk.png");
            this.imageList1.Images.SetKeyName(106, "hn.png");
            this.imageList1.Images.SetKeyName(107, "hr.png");
            this.imageList1.Images.SetKeyName(108, "ht.png");
            this.imageList1.Images.SetKeyName(109, "hu.png");
            this.imageList1.Images.SetKeyName(110, "id.png");
            this.imageList1.Images.SetKeyName(111, "ie.png");
            this.imageList1.Images.SetKeyName(112, "il.png");
            this.imageList1.Images.SetKeyName(113, "im.png");
            this.imageList1.Images.SetKeyName(114, "in.png");
            this.imageList1.Images.SetKeyName(115, "iq.png");
            this.imageList1.Images.SetKeyName(116, "ir.png");
            this.imageList1.Images.SetKeyName(117, "is.png");
            this.imageList1.Images.SetKeyName(118, "it.png");
            this.imageList1.Images.SetKeyName(119, "je.png");
            this.imageList1.Images.SetKeyName(120, "jm.png");
            this.imageList1.Images.SetKeyName(121, "jo.png");
            this.imageList1.Images.SetKeyName(122, "jp.png");
            this.imageList1.Images.SetKeyName(123, "ke.png");
            this.imageList1.Images.SetKeyName(124, "kg.png");
            this.imageList1.Images.SetKeyName(125, "kh.png");
            this.imageList1.Images.SetKeyName(126, "ki.png");
            this.imageList1.Images.SetKeyName(127, "km.png");
            this.imageList1.Images.SetKeyName(128, "kn.png");
            this.imageList1.Images.SetKeyName(129, "kp.png");
            this.imageList1.Images.SetKeyName(130, "kr.png");
            this.imageList1.Images.SetKeyName(131, "kw.png");
            this.imageList1.Images.SetKeyName(132, "ky.png");
            this.imageList1.Images.SetKeyName(133, "kz.png");
            this.imageList1.Images.SetKeyName(134, "la.png");
            this.imageList1.Images.SetKeyName(135, "lb.png");
            this.imageList1.Images.SetKeyName(136, "lc.png");
            this.imageList1.Images.SetKeyName(137, "li.png");
            this.imageList1.Images.SetKeyName(138, "lk.png");
            this.imageList1.Images.SetKeyName(139, "lr.png");
            this.imageList1.Images.SetKeyName(140, "ls.png");
            this.imageList1.Images.SetKeyName(141, "lt.png");
            this.imageList1.Images.SetKeyName(142, "lu.png");
            this.imageList1.Images.SetKeyName(143, "lv.png");
            this.imageList1.Images.SetKeyName(144, "ly.png");
            this.imageList1.Images.SetKeyName(145, "ma.png");
            this.imageList1.Images.SetKeyName(146, "mc.png");
            this.imageList1.Images.SetKeyName(147, "md.png");
            this.imageList1.Images.SetKeyName(148, "me.png");
            this.imageList1.Images.SetKeyName(149, "mg.png");
            this.imageList1.Images.SetKeyName(150, "mh.png");
            this.imageList1.Images.SetKeyName(151, "mk.png");
            this.imageList1.Images.SetKeyName(152, "ml.png");
            this.imageList1.Images.SetKeyName(153, "mm.png");
            this.imageList1.Images.SetKeyName(154, "mn.png");
            this.imageList1.Images.SetKeyName(155, "mo.png");
            this.imageList1.Images.SetKeyName(156, "mq.png");
            this.imageList1.Images.SetKeyName(157, "mr.png");
            this.imageList1.Images.SetKeyName(158, "ms.png");
            this.imageList1.Images.SetKeyName(159, "mt.png");
            this.imageList1.Images.SetKeyName(160, "mu.png");
            this.imageList1.Images.SetKeyName(161, "mv.png");
            this.imageList1.Images.SetKeyName(162, "mw.png");
            this.imageList1.Images.SetKeyName(163, "mx.png");
            this.imageList1.Images.SetKeyName(164, "my.png");
            this.imageList1.Images.SetKeyName(165, "mz.png");
            this.imageList1.Images.SetKeyName(166, "na.png");
            this.imageList1.Images.SetKeyName(167, "nc.png");
            this.imageList1.Images.SetKeyName(168, "ne.png");
            this.imageList1.Images.SetKeyName(169, "ng.png");
            this.imageList1.Images.SetKeyName(170, "ni.png");
            this.imageList1.Images.SetKeyName(171, "nl.png");
            this.imageList1.Images.SetKeyName(172, "no.png");
            this.imageList1.Images.SetKeyName(173, "np.png");
            this.imageList1.Images.SetKeyName(174, "nr.png");
            this.imageList1.Images.SetKeyName(175, "nz.png");
            this.imageList1.Images.SetKeyName(176, "om.png");
            this.imageList1.Images.SetKeyName(177, "pa.png");
            this.imageList1.Images.SetKeyName(178, "pe.png");
            this.imageList1.Images.SetKeyName(179, "pf.png");
            this.imageList1.Images.SetKeyName(180, "pg.png");
            this.imageList1.Images.SetKeyName(181, "ph.png");
            this.imageList1.Images.SetKeyName(182, "pk.png");
            this.imageList1.Images.SetKeyName(183, "pl.png");
            this.imageList1.Images.SetKeyName(184, "pr.png");
            this.imageList1.Images.SetKeyName(185, "ps.png");
            this.imageList1.Images.SetKeyName(186, "pt.png");
            this.imageList1.Images.SetKeyName(187, "pw.png");
            this.imageList1.Images.SetKeyName(188, "py.png");
            this.imageList1.Images.SetKeyName(189, "qa.png");
            this.imageList1.Images.SetKeyName(190, "re.png");
            this.imageList1.Images.SetKeyName(191, "ro.png");
            this.imageList1.Images.SetKeyName(192, "rs.png");
            this.imageList1.Images.SetKeyName(193, "ru.png");
            this.imageList1.Images.SetKeyName(194, "rw.png");
            this.imageList1.Images.SetKeyName(195, "sa.png");
            this.imageList1.Images.SetKeyName(196, "sb.png");
            this.imageList1.Images.SetKeyName(197, "sc.png");
            this.imageList1.Images.SetKeyName(198, "sd.png");
            this.imageList1.Images.SetKeyName(199, "se.png");
            this.imageList1.Images.SetKeyName(200, "sg.png");
            this.imageList1.Images.SetKeyName(201, "si.png");
            this.imageList1.Images.SetKeyName(202, "sk.png");
            this.imageList1.Images.SetKeyName(203, "sl.png");
            this.imageList1.Images.SetKeyName(204, "sm.png");
            this.imageList1.Images.SetKeyName(205, "sn.png");
            this.imageList1.Images.SetKeyName(206, "so.png");
            this.imageList1.Images.SetKeyName(207, "sr.png");
            this.imageList1.Images.SetKeyName(208, "st.png");
            this.imageList1.Images.SetKeyName(209, "sv.png");
            this.imageList1.Images.SetKeyName(210, "sy.png");
            this.imageList1.Images.SetKeyName(211, "sz.png");
            this.imageList1.Images.SetKeyName(212, "tc.png");
            this.imageList1.Images.SetKeyName(213, "td.png");
            this.imageList1.Images.SetKeyName(214, "tg.png");
            this.imageList1.Images.SetKeyName(215, "th.png");
            this.imageList1.Images.SetKeyName(216, "tj.png");
            this.imageList1.Images.SetKeyName(217, "tl.png");
            this.imageList1.Images.SetKeyName(218, "tm.png");
            this.imageList1.Images.SetKeyName(219, "tn.png");
            this.imageList1.Images.SetKeyName(220, "to.png");
            this.imageList1.Images.SetKeyName(221, "tr.png");
            this.imageList1.Images.SetKeyName(222, "tt.png");
            this.imageList1.Images.SetKeyName(223, "tv.png");
            this.imageList1.Images.SetKeyName(224, "tw.png");
            this.imageList1.Images.SetKeyName(225, "tz.png");
            this.imageList1.Images.SetKeyName(226, "ua.png");
            this.imageList1.Images.SetKeyName(227, "ug.png");
            this.imageList1.Images.SetKeyName(228, "us.png");
            this.imageList1.Images.SetKeyName(229, "uy.png");
            this.imageList1.Images.SetKeyName(230, "uz.png");
            this.imageList1.Images.SetKeyName(231, "va.png");
            this.imageList1.Images.SetKeyName(232, "vc.png");
            this.imageList1.Images.SetKeyName(233, "ve.png");
            this.imageList1.Images.SetKeyName(234, "vg.png");
            this.imageList1.Images.SetKeyName(235, "vi.png");
            this.imageList1.Images.SetKeyName(236, "vn.png");
            this.imageList1.Images.SetKeyName(237, "vu.png");
            this.imageList1.Images.SetKeyName(238, "ws.png");
            this.imageList1.Images.SetKeyName(239, "ye.png");
            this.imageList1.Images.SetKeyName(240, "za.png");
            this.imageList1.Images.SetKeyName(241, "zm.png");
            this.imageList1.Images.SetKeyName(242, "zw.png");
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.заблокироватьToolStripMenuItem,
            this.разблокироватьToolStripMenuItem,
            this.заблокироватьНа30СекундToolStripMenuItem,
            this.BlockNewStrip,
            this.дополнительноToolStripMenuItem,
            this.маркироватьToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(273, 136);
            // 
            // заблокироватьToolStripMenuItem
            // 
            this.заблокироватьToolStripMenuItem.Name = "заблокироватьToolStripMenuItem";
            this.заблокироватьToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.заблокироватьToolStripMenuItem.Text = "Заблокировать";
            this.заблокироватьToolStripMenuItem.Click += new System.EventHandler(this.заблокироватьToolStripMenuItem_Click);
            // 
            // разблокироватьToolStripMenuItem
            // 
            this.разблокироватьToolStripMenuItem.Name = "разблокироватьToolStripMenuItem";
            this.разблокироватьToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.разблокироватьToolStripMenuItem.Text = "Разблокировать";
            this.разблокироватьToolStripMenuItem.Click += new System.EventHandler(this.разблокироватьToolStripMenuItem_Click);
            // 
            // заблокироватьНа30СекундToolStripMenuItem
            // 
            this.заблокироватьНа30СекундToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.входящиеНа30СекундToolStripMenuItem,
            this.исходящиеНа30СекундToolStripMenuItem});
            this.заблокироватьНа30СекундToolStripMenuItem.Name = "заблокироватьНа30СекундToolStripMenuItem";
            this.заблокироватьНа30СекундToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.заблокироватьНа30СекундToolStripMenuItem.Text = "Заблокировать на 30 секунд";
            this.заблокироватьНа30СекундToolStripMenuItem.Click += new System.EventHandler(this.заблокироватьНа30СекундToolStripMenuItem_Click);
            // 
            // входящиеНа30СекундToolStripMenuItem
            // 
            this.входящиеНа30СекундToolStripMenuItem.Name = "входящиеНа30СекундToolStripMenuItem";
            this.входящиеНа30СекундToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.входящиеНа30СекундToolStripMenuItem.Text = "Входящие на 30 секунд";
            this.входящиеНа30СекундToolStripMenuItem.Click += new System.EventHandler(this.входящиеНа30СекундToolStripMenuItem_Click);
            // 
            // исходящиеНа30СекундToolStripMenuItem
            // 
            this.исходящиеНа30СекундToolStripMenuItem.Name = "исходящиеНа30СекундToolStripMenuItem";
            this.исходящиеНа30СекундToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.исходящиеНа30СекундToolStripMenuItem.Text = "Исходящие на 30 секунд";
            this.исходящиеНа30СекундToolStripMenuItem.Click += new System.EventHandler(this.исходящиеНа30СекундToolStripMenuItem_Click);
            // 
            // BlockNewStrip
            // 
            this.BlockNewStrip.Name = "BlockNewStrip";
            this.BlockNewStrip.Size = new System.Drawing.Size(272, 22);
            this.BlockNewStrip.Text = "Блокировать все новые соединения";
            this.BlockNewStrip.Click += new System.EventHandler(this.блокироватьВсеНовыеСоединенияToolStripMenuItem_Click);
            // 
            // дополнительноToolStripMenuItem
            // 
            this.дополнительноToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem,
            this.ipcheck2,
            this.ipcheck3,
            this.копироватьIPToolStripMenuItem,
            this.копироватьИндексToolStripMenuItem});
            this.дополнительноToolStripMenuItem.Name = "дополнительноToolStripMenuItem";
            this.дополнительноToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.дополнительноToolStripMenuItem.Text = "Дополнительно";
            // 
            // проверитьIPПоДругойGEOIPБазеToolStripMenuItem
            // 
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem.Name = "проверитьIPПоДругойGEOIPБазеToolStripMenuItem";
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem.Text = "Проверить IP по 2ip.com.ua";
            this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem.Click += new System.EventHandler(this.проверитьIPПоДругойGEOIPБазеToolStripMenuItem_Click);
            // 
            // ipcheck2
            // 
            this.ipcheck2.Name = "ipcheck2";
            this.ipcheck2.Size = new System.Drawing.Size(237, 22);
            this.ipcheck2.Text = "Проверить IP по ip-api.com";
            this.ipcheck2.Click += new System.EventHandler(this.ipcheck2_Click);
            // 
            // ipcheck3
            // 
            this.ipcheck3.Name = "ipcheck3";
            this.ipcheck3.Size = new System.Drawing.Size(237, 22);
            this.ipcheck3.Text = "Проверить IP по freegeoip.net";
            this.ipcheck3.Click += new System.EventHandler(this.ipcheck3_Click);
            // 
            // копироватьIPToolStripMenuItem
            // 
            this.копироватьIPToolStripMenuItem.Name = "копироватьIPToolStripMenuItem";
            this.копироватьIPToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.копироватьIPToolStripMenuItem.Text = "Копировать IP";
            this.копироватьIPToolStripMenuItem.Click += new System.EventHandler(this.копироватьIPToolStripMenuItem_Click);
            // 
            // копироватьИндексToolStripMenuItem
            // 
            this.копироватьИндексToolStripMenuItem.Name = "копироватьИндексToolStripMenuItem";
            this.копироватьИндексToolStripMenuItem.Size = new System.Drawing.Size(237, 22);
            this.копироватьИндексToolStripMenuItem.Text = "Копировать Индекс";
            this.копироватьИндексToolStripMenuItem.Click += new System.EventHandler(this.копироватьИндексToolStripMenuItem_Click);
            // 
            // маркироватьToolStripMenuItem
            // 
            this.маркироватьToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.синийToolStripMenuItem,
            this.зеленыйToolStripMenuItem,
            this.оранжевыйToolStripMenuItem,
            this.желтыйToolStripMenuItem,
            this.удалитьМаркерToolStripMenuItem});
            this.маркироватьToolStripMenuItem.Name = "маркироватьToolStripMenuItem";
            this.маркироватьToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.маркироватьToolStripMenuItem.Text = "Маркировать";
            // 
            // синийToolStripMenuItem
            // 
            this.синийToolStripMenuItem.Name = "синийToolStripMenuItem";
            this.синийToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.синийToolStripMenuItem.Text = "Синий";
            this.синийToolStripMenuItem.Click += new System.EventHandler(this.синийToolStripMenuItem_Click);
            // 
            // зеленыйToolStripMenuItem
            // 
            this.зеленыйToolStripMenuItem.Name = "зеленыйToolStripMenuItem";
            this.зеленыйToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.зеленыйToolStripMenuItem.Text = "Зеленый";
            this.зеленыйToolStripMenuItem.Click += new System.EventHandler(this.зеленыйToolStripMenuItem_Click);
            // 
            // оранжевыйToolStripMenuItem
            // 
            this.оранжевыйToolStripMenuItem.Name = "оранжевыйToolStripMenuItem";
            this.оранжевыйToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.оранжевыйToolStripMenuItem.Text = "Оранжевый";
            this.оранжевыйToolStripMenuItem.Click += new System.EventHandler(this.оранжевыйToolStripMenuItem_Click);
            // 
            // желтыйToolStripMenuItem
            // 
            this.желтыйToolStripMenuItem.Name = "желтыйToolStripMenuItem";
            this.желтыйToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.желтыйToolStripMenuItem.Text = "Желтый";
            this.желтыйToolStripMenuItem.Click += new System.EventHandler(this.желтыйToolStripMenuItem_Click);
            // 
            // удалитьМаркерToolStripMenuItem
            // 
            this.удалитьМаркерToolStripMenuItem.Name = "удалитьМаркерToolStripMenuItem";
            this.удалитьМаркерToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.удалитьМаркерToolStripMenuItem.Text = "Удалить маркер";
            this.удалитьМаркерToolStripMenuItem.Click += new System.EventHandler(this.удалитьМаркерToolStripMenuItem_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(12, 35);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listView1);
            this.splitContainer1.Size = new System.Drawing.Size(560, 481);
            this.splitContainer1.SplitterDistance = 197;
            this.splitContainer1.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(550, 529);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(22, 21);
            this.button1.TabIndex = 12;
            this.button1.Text = "&a";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cTM
            // 
            this.cTM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cTM.AutoSize = true;
            this.cTM.Location = new System.Drawing.Point(529, 533);
            this.cTM.Name = "cTM";
            this.cTM.Size = new System.Drawing.Size(15, 14);
            this.cTM.TabIndex = 13;
            this.cTM.UseVisualStyleBackColor = true;
            this.cTM.CheckedChanged += new System.EventHandler(this.cTM_CheckedChanged);
            // 
            // cRem
            // 
            this.cRem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cRem.AutoSize = true;
            this.cRem.Location = new System.Drawing.Point(508, 533);
            this.cRem.Name = "cRem";
            this.cRem.Size = new System.Drawing.Size(15, 14);
            this.cRem.TabIndex = 14;
            this.cRem.UseVisualStyleBackColor = true;
            this.cRem.CheckedChanged += new System.EventHandler(this.cRem_CheckedChanged);
            // 
            // AbuseSniffer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.ClientSize = new System.Drawing.Size(584, 561);
            this.Controls.Add(this.cRem);
            this.Controls.Add(this.cTM);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.cmbInterfaces);
            this.Controls.Add(this.btnStart);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.MinimumSize = new System.Drawing.Size(590, 520);
            this.Name = "AbuseSniffer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PortAbuse - Sniffer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SnifferForm_FormClosing);
            this.Load += new System.EventHandler(this.SnifferForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.AS_MouseDown);
            this.MouseLeave += new System.EventHandler(this.AS_MouseLeave);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.AS_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.AS_MouseUp);
            this.Resize += new System.EventHandler(this.AbuseSniffer_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox cmbInterfaces;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader RemoteIP;
        private System.Windows.Forms.ColumnHeader RemoteHost;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem заблокироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem разблокироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьIPToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader RemCountry;
        private System.Windows.Forms.ToolStripMenuItem заблокироватьНа30СекундToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem BlockNewStrip;
        private System.Windows.Forms.ToolStripMenuItem проверитьIPПоДругойGEOIPБазеToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStripMenuItem дополнительноToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem маркироватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem синийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem зеленыйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оранжевыйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem желтыйToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьМаркерToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьИндексToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem входящиеНа30СекундToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem исходящиеНа30СекундToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem ipcheck2;
        private System.Windows.Forms.ToolStripMenuItem ipcheck3;
        private System.Windows.Forms.CheckBox cTM;
        private System.Windows.Forms.CheckBox cRem;
        private System.Windows.Forms.ImageList imageList1;
    }
}

