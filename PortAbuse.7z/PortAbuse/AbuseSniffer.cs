﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Diagnostics;
using System.Security.Principal;
using System.Xml.Linq;
using System.Threading;
using System.IO;

namespace PortAbuse
{
    public enum Protocol
    {
        TCP = 6,
        UDP = 17,
        Unknown = -1
    };

    public partial class AbuseSniffer : Form
    {
        private Socket mainSocket;                          //The socket which captures all incoming packets
        private byte[] byteData = new byte[65536];
        private bool bContinueCapturing = false;            //A flag to check if packets are to be captured or not
        private delegate void AddTreeNode(TreeNode node);
        private delegate void AddListIP(ListViewItem item);

        public bool IsUserAdministrator()
        {
            bool isAdmin;
            try
            {
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(user);
                isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (UnauthorizedAccessException)
            {
                isAdmin = false;
            }
            catch (Exception)
            {
                isAdmin = false;
            }
            return isAdmin;
        }
        //public bool AcceptPC = false;
        //Thread SystemCheck = null;
        //string FreeArgs = "7480-274E-E062-26C0-A090-7D44-54E9-551C";
        string pName = string.Empty;
        public AbuseSniffer(string Arg = "", string _pName = "")
        {
            InitializeComponent();            

            this.Icon = Properties.Resources.internet_connection_manager;
            listView1.ContextMenuStrip = contextMenuStrip1;
            //if (HWID.GetHash(Arg) == FreeArgs)
            //    AcceptPC = true;
            //else
            //{
            //    SystemCheck = new Thread(() => Program.CheckPC(this));
            //    SystemCheck.Start();
            //    this.Text = "PortAbuse - Sniffer [HWID Check In Progress]";
            //}
            if (_pName != "")
                pName = _pName;                      
        }
        //public void SetAcceptPC(bool YesOrNot)
        //{
        //    AcceptPC = YesOrNot;
        //    if (!AcceptPC)
        //        ShutIT();
        //    else
        //        this.Text = "PortAbuse - Sniffer [HWID Check Done]";
        //}
        public void ShutIT()
        {
            this.Close();            
        }
        int cbSelIndx = -1;
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (cmbInterfaces.Text == "")
            {
                MessageBox.Show("Выберите интерфейс.", "PortAbuse - Interface Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                if (!bContinueCapturing)        //&& AcceptPC
                {
                    //Clear old data
                    string ThisText = this.Text;
                    this.Text = ThisText + "...";
                    this.BackColor = Color.OrangeRed;
                    ShutAll = true;                    
                    foreach (ExThread ExTd in tdList)
                    {
                        if (ExTd.td.IsAlive && ExTd.td.Name != "UnBlock30")
                        {
                            ExTd.td.Abort();
                            //tdList.Remove(td);
                        }
                        else if (ExTd.td.IsAlive && ExTd.td.Name == "UnBlock30")
                        {
                            while (ExTd.td.IsAlive)
                            {
                                this.Text = "[" + (ExTd.tdLiveTime - (DateTime.Now - ExTd.tdTime).Seconds) + "]" + ThisText;
                                for (int i = 0; (i < 3 && ExTd.td.IsAlive); i++)
                                {                                    
                                    this.Text += ".";
                                    Thread.Sleep(1000);
                                }
                            }
                        }
                    }
                    GeoRunning = false;
                    GeoRequests = 0;
                    this.Text = "PortAbuse - Sniffer";
                    this.BackColor = Color.GhostWhite;
                    tdList.Clear();
                    ShutAll = false;
                    this.Text = ThisText;
                    treeView.Nodes.Clear();

                    List<IPEntry> ieIP2 = IPList.Where(x => x.Marked == false).ToList();
                    for (int i = ieIP2.Count - 1; i >= 0; i--)
                    {
                        IPList.Remove(ieIP2[i]);
                    }

                    //IPList = new List<IPEntry>();
                    //for (int i = listView1.Items.Count - 1; i >= 0; i--)
                    //{
                    //    if (listView1.Items[i].Tag != "m")
                    //    {
                    //        listView1.Items.Remove(listView1.Items[i]);
                    //        listView1.Items.RemoveByKey("");
                    //    }
                    //}
                    List<ListViewItem> ieLVI = listView1.Items.Cast<ListViewItem>().Where(x => x.Name != "m").ToList();
                    for (int i = ieLVI.Count - 1; i >= 0; i--)
                    {
                        listView1.Items.Remove(ieLVI[i]);
                    }
                    //listView1.Items.Clear();
                    cmbInterfaces.Enabled = false;
                    comboBox1.Enabled = false;
                    button4.Enabled = false;

                    

                    //Start capturing the packets...
                    cbSelIndx = comboBox1.SelectedIndex;
                    btnStart.Text = "&Stop";
                    DoingWork = true;
                    Thread td = new Thread(() => DoHardWork());
                    td.Start();
                    tdList.Add(new ExThread(td));

                    bContinueCapturing = true;

                    IPEndPoint ipe = new IPEndPoint(IPAddress.Parse(cmbInterfaces.Text), 0);

                    InterfaceLocalIP = cmbInterfaces.Text;

                    //For sniffing the socket to capture the packets has to be a raw socket, with the
                    //address family being of type internetwork, and protocol being IP

                    //mainSocket = new Socket(AddressFamily.InterNetwork, SocketType.Raw, ProtocolType.IP);
                    mainSocket = new Socket(ipe.AddressFamily, SocketType.Raw, ProtocolType.IP);

                    //Bind the socket to the selected IP address  
                    mainSocket.Bind(ipe);
                    //Set the socket  options
                    mainSocket.SetSocketOption(SocketOptionLevel.IP,            //Applies only to IP packets
                                               SocketOptionName.HeaderIncluded, //Set the include the header
                                               true);                           //option to true

                    byte[] byTrue = new byte[4] {1, 0, 0, 0};
                    byte[] byOut = new byte[4]{1, 0, 0, 0}; //Capture outgoing packets
                    //Socket.IOControl is analogous to the WSAIoctl method of Winsock 2
                    try
                    {
                        mainSocket.IOControl(IOControlCode.ReceiveAll, byTrue, byOut);           //Equivalent to SIO_RCVALL constant   //of Winsock 2                                             
                    }                  
                    catch (SocketException sEx)
                    {
                        this.Text = "PortAbuse - Sniffer" + " [ERR:" + sEx.ErrorCode+ "]";
                    }
                    //Start receiving the packets asynchronously
                    mainSocket.BeginReceive(byteData, 0, byteData.Length, SocketFlags.None,
                        new AsyncCallback(OnReceive), null);
                }
                else if (bContinueCapturing) //&& AcceptPC
                {
                    DoingWork = false;
                    btnStart.Text = "&Start";
                    bContinueCapturing = false;
                    cmbInterfaces.Enabled = true;
                    comboBox1.Enabled = true;
                    button4.Enabled = true;
                    //To stop capturing the packets close the socket
                    mainSocket.Close();
                }
                else
                {
                    MessageBox.Show(this, "Дождитесь завершения проверка HWID", "PortAbuse - HWID Check", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PortAbuse - Start Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnReceive(IAsyncResult ar)
        {
            try
            {
                int nReceived = mainSocket.EndReceive(ar);
                if (nReceived > 65536) nReceived = 65536;
                //Analyze the bytes received...  
                //Thread td = new Thread(() => ParseData(byteData, nReceived));
                //td.Start();
                //tdList.Add(new ExThread(td));
                ParseData(byteData, nReceived);

                if (bContinueCapturing)     
                {
                    byteData = new byte[65536];
                    
                    //Another call to BeginReceive so that we continue to receive the incoming
                    //packets
                    mainSocket.BeginReceive(byteData, 0, byteData.Length, SocketFlags.None,
                        new AsyncCallback(OnReceive), null);
                }
            }
            catch (ObjectDisposedException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "PortAbuse - Receive Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }            
        }
        List<IPEntry> IPList = new List<IPEntry>();
        string InterfaceLocalIP = "";
        List<ExThread> tdList = new List<ExThread>();
        private void ParseData(byte[] byteData, int nReceived)
        {
            TreeNode rootNode = new TreeNode();            
            //Since all protocol packets are encapsulated in the IP datagram
            //so we start by parsing the IP header and see what protocol data
            //is being carried by it
            IPHeader ipHeader = new IPHeader(byteData, nReceived);

            bool doAdd = false;
            TreeNode ipNode = MakeIPTreeNode(ipHeader, ref doAdd);
            rootNode.Nodes.Add(ipNode);

            //Now according to the protocol being carried by the IP datagram we parse 
            //the data field of the datagram
            
            switch (ipHeader.ProtocolType)
            {
                case Protocol.TCP:

                    TCPHeader tcpHeader = new TCPHeader(ipHeader.Data,              //IPHeader.Data stores the data being 
                                                                                    //carried by the IP datagram
                                                        ipHeader.MessageLength);//Length of the data field                    

                    TreeNode tcpNode = MakeTCPTreeNode(tcpHeader, ref doAdd);

                    rootNode.Nodes.Add(tcpNode);

                    //If the port is equal to 53 then the underlying protocol is DNS
                    //Note: DNS can use either TCP or UDP thats why the check is done twice
                    if (tcpHeader.DestinationPort == "53" || tcpHeader.SourcePort == "53")
                    {
                        TreeNode dnsNode = MakeDNSTreeNode(tcpHeader.Data, (int)tcpHeader.MessageLength);
                        rootNode.Nodes.Add(dnsNode);
                    }

                    break;

                case Protocol.UDP:

                    UDPHeader udpHeader = new UDPHeader(ipHeader.Data,              //IPHeader.Data stores the data being 
                                                                                    //carried by the IP datagram
                                                       (int)ipHeader.MessageLength);//Length of the data field                    

                    TreeNode udpNode = MakeUDPTreeNode(udpHeader, ref doAdd);

                    rootNode.Nodes.Add(udpNode);

                    //If the port is equal to 53 then the underlying protocol is DNS
                    //Note: DNS can use either TCP or UDP thats why the check is done twice
                    if (udpHeader.DestinationPort == "53" || udpHeader.SourcePort == "53")
                    {

                        TreeNode dnsNode = MakeDNSTreeNode(udpHeader.Data,
                                                           //Length of UDP header is always eight bytes so we subtract that out of the total 
                                                           //length to find the length of the data
                                                           Convert.ToInt32(udpHeader.Length) - 8);  
                        rootNode.Nodes.Add(dnsNode);
                    }

                    break;

                case Protocol.Unknown:
                    break;
            }

            if (cbSelIndx < 1) doAdd = true;           

            //Thread safe adding of the nodes
            if (doAdd)
            {
                rootNode.Text = ipHeader.SourceAddress.ToString() + "-" +
                ipHeader.DestinationAddress.ToString();
                AddTreeNode addTreeNode = new AddTreeNode(OnAddTreeNode);
                AddListIP addListIP = new AddListIP(OnAddListIP);
                bool noMatch = true;
                if (ipHeader.SourceAddress.ToString() != InterfaceLocalIP)
                {
                    foreach (IPEntry item in IPList)
                    {
                        if (item.RemIP == ipHeader.SourceAddress.ToString())
                        {
                            noMatch = false;
                            break;
                        }
                    }
                    if (noMatch)
                    {
                        for (int i = 0; i < IPWhiteList.Length; i++)
                        {
                            if (ipHeader.SourceAddress.ToString() == IPWhiteList[i])
                            {
                                noMatch = false;
                                break;
                            }
                        }
                    }
                }
                else if (ipHeader.SourceAddress.ToString() == InterfaceLocalIP)
                {
                    foreach (IPEntry item in IPList)
                    {
                        if (item.RemIP == ipHeader.DestinationAddress.ToString())
                        {
                            noMatch = false;
                            break;
                        }
                    }
                    if (noMatch)
                    {
                        for (int i = 0; i < IPWhiteList.Length; i++)
                        {
                            if (ipHeader.DestinationAddress.ToString() == IPWhiteList[i])
                            {
                                noMatch = false;
                                break;
                            }
                        }
                    }
                }
                else
                    noMatch = false;

                if (noMatch && !BlockNew && (ipHeader.SourceAddress.ToString() != InterfaceLocalIP))
                {
                    IPEntry newIP = new IPEntry(ipHeader.DestinationAddress.ToString(), ipHeader.SourceAddress.ToString());
                    IPList.Add(newIP);
                    ListViewItem item1 = new ListViewItem(ipHeader.SourceAddress.ToString());
                    item1.Tag = newIP;
                    item1.Name = "";
                    item1.SubItems.Add("");
                    item1.SubItems.Add("");
                    listView1.Invoke(addListIP, new object[] { item1 });
                    Thread td = new Thread(() => InsertGeoDataQueue(item1, item1.SubItems[0].Text));
                    td.Start();
                    Thread td2 = new Thread(() => GetIPHost(item1, item1.SubItems[0].Text));
                    td2.Start();
                    tdList.Add(new ExThread(td)); tdList.Add(new ExThread(td2));
                    treeView.Invoke(addTreeNode, new object[] { rootNode });
                }
                else if (noMatch && !BlockNew && (ipHeader.SourceAddress.ToString() == InterfaceLocalIP))
                {
                    IPEntry newIP = new IPEntry(ipHeader.SourceAddress.ToString(), ipHeader.DestinationAddress.ToString());
                    IPList.Add(newIP);
                    ListViewItem item1 = new ListViewItem(ipHeader.DestinationAddress.ToString());
                    item1.Tag = newIP;
                    item1.Name = "";
                    item1.SubItems.Add("");
                    item1.SubItems.Add("");
                    listView1.Invoke(addListIP, new object[] { item1 });
                    Thread td = new Thread(() => InsertGeoDataQueue(item1, item1.SubItems[0].Text));
                    td.Start();
                    Thread td2 = new Thread(() => GetIPHost(item1, item1.SubItems[0].Text));
                    td2.Start();
                    tdList.Add(new ExThread(td)); tdList.Add(new ExThread(td2));
                    treeView.Invoke(addTreeNode, new object[] { rootNode });
                }
                else if (noMatch && BlockNew)
                {
                    Do30SecBlock(ipHeader.SourceAddress.ToString());
                }
            }            
        }

        //Helper function which returns the information contained in the IP header as a
        //tree node
        private TreeNode MakeIPTreeNode(IPHeader ipHeader, ref bool _DoAdd)
        {
            TreeNode ipNode = new TreeNode();
            ipNode.Text = "IP";            
            ipNode.Nodes.Add ("Ver: " + ipHeader.Version);
            ipNode.Nodes.Add ("Header Length: " + ipHeader.HeaderLength);
            ipNode.Nodes.Add ("Differntiated Services: " + ipHeader.DifferentiatedServices);
            ipNode.Nodes.Add("Total Length: " + ipHeader.TotalLength);
            ipNode.Nodes.Add("Identification: " + ipHeader.Identification);
            ipNode.Nodes.Add("Flags: " + ipHeader.Flags);
            ipNode.Nodes.Add("Fragmentation Offset: " + ipHeader.FragmentationOffset);
            ipNode.Nodes.Add("Time to live: " + ipHeader.TTL);
            switch (ipHeader.ProtocolType)
            {
                case Protocol.TCP:
                    ipNode.Nodes.Add ("Protocol: " + "TCP");
                    break;
                case Protocol.UDP:
                    ipNode.Nodes.Add ("Protocol: " + "UDP");
                    break;
                case Protocol.Unknown:
                    ipNode.Nodes.Add ("Protocol: " + "Unknown");
                    break;
            }
            ipNode.Nodes.Add("Checksum: " + ipHeader.Checksum);
            ipNode.Nodes.Add("Source: " + ipHeader.SourceAddress.ToString());
            ipNode.Nodes.Add("Destination: " + ipHeader.DestinationAddress.ToString());

            return ipNode;
        }

        //Helper function which returns the information contained in the TCP header as a
        //tree node
        private TreeNode MakeTCPTreeNode(TCPHeader tcpHeader, ref bool _DoAdd)
        {
            TreeNode tcpNode = new TreeNode();

            tcpNode.Text = "TCP";
            if (ProPortsSelected != null)
            {
                IEnumerable<PortMaker.Port> CheckArray = ProPortsSelected.Where(mc => (mc.port_number == tcpHeader.DestinationPort
                    || mc.port_number == tcpHeader.SourcePort) && mc.protocol == "TCPv4");
                if (CheckArray.Count() > 0) _DoAdd = true;
            }
            tcpNode.Nodes.Add("Source Port: " + tcpHeader.SourcePort);
            tcpNode.Nodes.Add("Destination Port: " + tcpHeader.DestinationPort);
            tcpNode.Nodes.Add("Sequence Number: " + tcpHeader.SequenceNumber);

            if (tcpHeader.AcknowledgementNumber != "")
                tcpNode.Nodes.Add("Acknowledgement Number: " + tcpHeader.AcknowledgementNumber);

            tcpNode.Nodes.Add("Header Length: " + tcpHeader.HeaderLength);
            tcpNode.Nodes.Add("Flags: " + tcpHeader.Flags);
            tcpNode.Nodes.Add("Window Size: " + tcpHeader.WindowSize);
            tcpNode.Nodes.Add("Checksum: " + tcpHeader.Checksum);

            if (tcpHeader.UrgentPointer != "")
                tcpNode.Nodes.Add("Urgent Pointer: " + tcpHeader.UrgentPointer);

            return tcpNode;
        }

        //Helper function which returns the information contained in the UDP header as a
        //tree node
        private TreeNode MakeUDPTreeNode(UDPHeader udpHeader, ref bool _DoAdd)
        {           
            TreeNode udpNode = new TreeNode();
            if (ProPortsSelected != null)
            {
                IEnumerable<PortMaker.Port> CheckArray = ProPortsSelected.Where(mc => (mc.port_number == udpHeader.DestinationPort
                    || mc.port_number == udpHeader.SourcePort) && mc.protocol == "UDPv4");
                if (CheckArray.Count() > 0)
                {
                    _DoAdd = true;
                }
            }
            udpNode.Text = "UDP";
            udpNode.Nodes.Add("Source Port: " + udpHeader.SourcePort);
            udpNode.Nodes.Add("Destination Port: " + udpHeader.DestinationPort);
            udpNode.Nodes.Add("Length: " + udpHeader.Length);
            udpNode.Nodes.Add("Checksum: " + udpHeader.Checksum);            
            return udpNode;
        }

        //Helper function which returns the information contained in the DNS header as a
        //tree node
        private TreeNode MakeDNSTreeNode(byte[] byteData, int nLength)
        {
            DNSHeader dnsHeader = new DNSHeader(byteData, nLength);

            TreeNode dnsNode = new TreeNode();

            dnsNode.Text = "DNS";
            dnsNode.Nodes.Add("Identification: " + dnsHeader.Identification);
            dnsNode.Nodes.Add("Flags: " + dnsHeader.Flags);
            dnsNode.Nodes.Add("Questions: " + dnsHeader.TotalQuestions);
            dnsNode.Nodes.Add("Answer RRs: " + dnsHeader.TotalAnswerRRs);
            dnsNode.Nodes.Add("Authority RRs: " + dnsHeader.TotalAuthorityRRs);
            dnsNode.Nodes.Add("Additional RRs: " + dnsHeader.TotalAdditionalRRs);

            return dnsNode;
        }

        private void OnAddTreeNode(TreeNode node)
        {
            treeView.Nodes.Add(node);
        }
        private void OnAddListIP(ListViewItem item)
        {
            listView1.Items.Add(item);
            this.Text = "PortAbuse - Sniffer [" + listView1.Items.Count + "]";
        }

        private void WorkState(string Caption)
        {
            btnStart.Text = Caption;
        }

        private bool DoingWork = true;
        private void DoHardWork()
        {
            string caption = "&Stop";
            while (DoingWork)
            {
                caption = "&Stop";
                for (int i = 0; (i < 4) && DoingWork; i++)
                {
                    Thread.Sleep(700);                    
                    Invoke(new Action(() =>
                    {
                        WorkState(caption);
                    }));
                    caption += ".";
                }
            }
            Invoke(new Action(() =>
            {
                WorkState("&Start");
            })); 
            //btnStart.Text = Caption;
        }
        string[] IPWhiteList;
        private void SnifferForm_Load(object sender, EventArgs e)
        {
            string strIP = null;
            IPWhiteList = new string[] { "94.141.164.159", "95.28.47.206" };

            //listView1.Columns[1].Width = 0;

            IPHostEntry HosyEntry = Dns.GetHostEntry((Dns.GetHostName()));
            if (HosyEntry.AddressList.Length > 0)
            {
                foreach (IPAddress ip in HosyEntry.AddressList)
                {
                    if (ip.AddressFamily != AddressFamily.InterNetworkV6)
                    {
                        strIP = ip.ToString();
                        cmbInterfaces.Items.Add(strIP);
                    }
                }
            }
            if (cmbInterfaces.Items.Count == 1)
            {
                cmbInterfaces.SelectedIndex = 0;
            }
            this.Activate();
            if (!IsUserAdministrator())
            {                
                MessageBox.Show(this, "Требуются права администратора!", "PortAbuse ERROR", MessageBoxButtons.OK, MessageBoxIcon.Warning);               
                this.Close();
            }
            LoadProcesses();
        }

        private void SnifferForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (bContinueCapturing)
            {
                mainSocket.Close();
            }
            //if (SystemCheck != null)
            //    if (SystemCheck.IsAlive)
            //        SystemCheck.Abort();
            string ThisCaption = "Закрываю все активные потоки";
            this.Text = ThisCaption + "...";            
            ShutAll = true;
            foreach (ExThread ExTd in tdList)
            {
                if (ExTd.td.IsAlive && ExTd.td.Name != "UnBlock30")
                {
                    ExTd.td.Abort();
                }
                else if (ExTd.td.IsAlive && ExTd.td.Name == "UnBlock30")
                {
                    this.BackColor = Color.Red;
                    while (ExTd.td.IsAlive)
                    {
                        for (int i = 0; i < 3; i++)
                        {
                            this.Text = "[" + (ExTd.tdLiveTime - (DateTime.Now - ExTd.tdTime).Seconds) + "]" + ThisCaption;
                            this.Text += ".";
                            Thread.Sleep(1000);
                        }                        
                    }
                }
            }
            //if (this.Owner != null)
            //    ((Form1)this.Owner).ShowMe();
        }


        #region Processes
        private void button4_Click(object sender, EventArgs e)
        {
            LoadProcesses();
            comboBox1.Text = "Выберите процесс";
            this.BringToFront();
            this.Focus();
        }
        List<PortMaker.Port> ProPortsAll = new List<PortMaker.Port>();
        IEnumerable<PortMaker.Port> ProPortsSelected;
        bool DoRefresh = false;
        private void LoadProcesses(bool showAll = false)
        {
            comboBox1.DataSource = null;
            DoRefresh = true;
            Thread td = new Thread(() => getProcessList(showAll));
            td.Start();
            tdList.Add(new ExThread(td));            
            DoRefresh = false;
        }
        private void getProcessList(bool showAll = false)
        {
            Process[] MyProcess = Process.GetProcesses();
            IEnumerable<Process> ProcOrder = MyProcess.OrderBy(proc => proc.ProcessName);
            List<Item> LI = new List<Item>();
            ProPortsAll = PortMaker.GetNetStatPorts(); 
            Invoke(new Action(() =>
            {
                RefreshComboboxList(LI, ProcOrder, showAll);
            }));                       
        }
        private void RefreshComboboxList(List<Item> LI, IEnumerable<Process> ProcOrder, bool showAll = false)
        {
            LI.Add(new Item(-9999, "----Выберите процесс----"));
            int ProPortsDebug;
            foreach (Process item in ProcOrder)
            {
                ProPortsDebug = ProPortsAll.Where(mc => mc.process_name == item.ProcessName).Count();
                if (ProPortsDebug > 0 || showAll)
                    if (pName == string.Empty)
                        LI.Add(new Item(item.Id, item.ProcessName + " PID:" + item.Id, item.ProcessName));
                    else if (item.ProcessName == pName)
                        LI.Add(new Item(item.Id, item.ProcessName + " PID:" + item.Id, item.ProcessName));
            }
            //comboBox1.DataSource = null;
            comboBox1.DataSource = LI;
            comboBox1.DisplayMember = "Name";
            comboBox1.ValueMember = "Value";
            comboBox1.SelectedIndex = 0;            
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!DoRefresh)
            {
                ComboBox cb = (ComboBox)sender;
                if (cb.SelectedIndex > 0)
                {
                    Item item = (Item)cb.SelectedItem;
                    ProPortsSelected = ProPortsAll.Where(mc => mc.process_name == item.InstanceName);
                }
            }
        }
        #endregion


        #region Block-Unblock
        private void заблокироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                string SRemIP = liItem.SubItems[0].Text;
                DoBlock(SRemIP, liItem);
            }
        }
        private void DoBlock(string _IP, ListViewItem liItem = null, bool onlyOut = false, bool onlyIn = false)
        {
            if (_IP != "")
            {
                string SRemIP = _IP;
                IPEndPoint remIP = new IPEndPoint(IPAddress.Parse(SRemIP), 0);
                string blockName = SRemIP + "-BLOCK_PA";
                string Args = "advfirewall firewall add rule name=" + blockName + " dir=out interface=any action=block remoteip=" + SRemIP + "/32";
                string Args2 = "advfirewall firewall add rule name=" + blockName + " dir=in interface=any action=block remoteip=" + SRemIP + "/32";

                ProcessStartInfo ps = new ProcessStartInfo();
                ps.Arguments = string.Format("/c start \"notitle\" /B \"{0}\" {1}", "netsh.exe", Args);
                ps.FileName = "cmd.exe";
                ps.WindowStyle = ProcessWindowStyle.Hidden;
                //ps.RedirectStandardInput = true;
                //ps.RedirectStandardOutput = true;
                //ps.RedirectStandardError = true;

                ProcessStartInfo ps2 = new ProcessStartInfo();
                ps2.Arguments = string.Format("/c start \"notitle\" /B \"{0}\" {1}", "netsh.exe", Args2);
                ps2.FileName = "cmd.exe";
                ps2.WindowStyle = ProcessWindowStyle.Hidden;
                //ps2.RedirectStandardInput = true;
                //ps2.RedirectStandardOutput = true;
                //ps2.RedirectStandardError = true;

                Process p1 = new Process();
                p1.StartInfo = ps;
                if (!onlyOut)
                    p1.Start();

                Process p2 = new Process();
                p2.StartInfo = ps2;
                if (!onlyIn)
                    p2.Start();

                if (liItem != null)
                    liItem.BackColor = Color.Red; 
            }
        }
        private void DoUnBlock(string _IP, ListViewItem liItem = null)
        {
            string blockName = _IP + "-BLOCK_PA";
            string Args = "advfirewall firewall delete rule name=" + blockName;

            ProcessStartInfo ps = new ProcessStartInfo();
            ps.Arguments = string.Format("/c start \"notitle\" /B \"{0}\" {1}", "netsh.exe", Args);
            ps.FileName = "cmd.exe";
            ps.WindowStyle = ProcessWindowStyle.Hidden;


            Process p1 = new Process();
            p1.StartInfo = ps;
            p1.Start();

            if (liItem != null)
                liItem.BackColor = Color.White;
        }
        private void разблокироватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = new ListViewItem();
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                string SRemIP = liItem.SubItems[0].Text;
                DoUnBlock(SRemIP, liItem);
            }
        }
        private void копироватьIPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                Clipboard.SetText(liItem.SubItems[0].Text);
            }
        }
        private void копироватьИндексToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null && liItem.SubItems[2].Tag != null && liItem.SubItems[2].Tag.ToString() != "")
            {
                Clipboard.SetText((string)liItem.SubItems[2].Tag);
            }
        }
#endregion

        #region GEO
        private void UpdateListCountry(ListViewItem item, string LocName, string Zip, string CountryCode)
        {
            item.SubItems[2].Text = LocName;
            item.SubItems[2].Tag = Zip;
            //var iList = item.ImageList;
            item.ImageKey = CountryCode + ".png";
            
            //item.ImageKey = "ru";
            //item.SubItems[3].
        }
        private void UpdateListHost(ListViewItem item, string HostName)
        {
            item.SubItems[1].Text = HostName;
        }
        private string GetLocationByIP(string IP, ref string Zip, ref string CountryCode)
        {
            string LocName = "";
            string url = "http://api.2ip.com.ua/geo.xml?ip=" + IP;

            try
            {
                WebRequest request = WebRequest.Create(url);
                request.Timeout = 10000;
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    Encoding encoding = response.CharacterSet != "" ? Encoding.GetEncoding(response.CharacterSet) : null;
                    using (var sr = encoding != null ? new StreamReader(response.GetResponseStream(), encoding) :
                                                           new StreamReader(response.GetResponseStream(), true))
                    {

                        string response2 = sr.ReadToEnd();
                        XDocument doc = XDocument.Parse(response2);
                        XElement _GeoData = doc.Element("geo_api");
                        string _LocCountry = _GeoData.Element("country_rus").Value;
                        string _LocCity = _GeoData.Element("city_rus").Value;
                        Zip = _GeoData.Element("zip_code").Value;
                        if (Zip == "-") Zip = "";
                        string _Zip = Zip;
                        CountryCode = _GeoData.Element("country_code").Value.ToLower();
                        LocName = (_Zip == "" ? "" : "[" + _Zip + "] ") + (_LocCountry == "" ? "[Неизвестно]" : _LocCountry) + " - " + (_LocCity == "" ? "[Неизвестно]" : _LocCity);
                        //Invoke(new Action(() =>
                        //{
                        //    UpdateListCountry(item, LocName);
                        //})); 
                    }
                }
            }
            catch
            {
                LocName = "";
            }
            return LocName;
        }
        private string GetLocationByIP2(string IP, ref string Zip, ref string CountryCode)
        {
            string LocName = "";
            string url = "http://ip-api.com/xml/" + IP;

            try
            {
                WebRequest request = WebRequest.Create(url);
                request.Timeout = 10000;
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    Encoding encoding = response.CharacterSet != "" ? Encoding.GetEncoding(response.CharacterSet) : null;
                    using (var sr = encoding != null ? new StreamReader(response.GetResponseStream(), encoding) :
                                                           new StreamReader(response.GetResponseStream(), true))
                    {
                        string response2 = sr.ReadToEnd();
                        XDocument doc = XDocument.Parse(response2);
                        XElement _GeoData = doc.Element("query");
                        string _LocCountry = _GeoData.Element("country").Value;
                        string _LocCity = _GeoData.Element("city").Value;
                        Zip = _GeoData.Element("zip").Value;
                        string _Zip = Zip;
                        string _Isp = _GeoData.Element("isp").Value;
                        CountryCode = _GeoData.Element("countryCode").Value.ToLower();

                        LocName = (_Zip == "" ? "" : "[" + _Zip + "] ") + (_LocCountry == "" ? "[Неизвестно]" : _LocCountry) + " - " + (_LocCity == "" ? "[Неизвестно]" : _LocCity) + (_Isp == "" ? "" : " - [" + _Isp + "] ");
                    }
                }
            }
            catch
            {
                LocName = "";
            }
            return LocName;
            //Invoke(new Action(() =>
            //    {
            //        UpdateListCountry(item, LocName);
            //    })); 
        }
        private string GetLocationByIP3(string IP, ref string Zip, ref string CountryCode)
        {
            string LocName = "";
            string url = "http://freegeoip.net/xml/" + IP;

            try
            {
                WebRequest request = WebRequest.Create(url);
                request.Timeout = 10000;
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    Encoding encoding = response.CharacterSet != "" ? Encoding.GetEncoding(response.CharacterSet) : null;
                    using (var sr = encoding != null ? new StreamReader(response.GetResponseStream(), encoding) :
                                                           new StreamReader(response.GetResponseStream(), true))
                    {
                        string response2 = sr.ReadToEnd();
                        XDocument doc = XDocument.Parse(response2);
                        XElement _GeoData = doc.Element("Response");
                        string _LocCountry = _GeoData.Element("CountryName").Value;
                        string _LocCity = _GeoData.Element("City").Value;
                        Zip = _GeoData.Element("ZipCode").Value;
                        string _Zip = Zip;
                        CountryCode = _GeoData.Element("CountryCode").Value.ToLower();
                        
                        //string _Isp = _GeoData.Element("isp").Value;
                        LocName = (_Zip == "" ? "" : "[" + _Zip + "] ") + (_LocCountry == "" ? "[Неизвестно]" : _LocCountry) + " - " + (_LocCity == "" ? "[Неизвестно]" : _LocCity);
                    }
                }
            }
            catch
            {
                LocName = "";
            }
            return LocName;
            //Invoke(new Action(() =>
            //{
            //    UpdateListCountry(item, LocName);
            //}));
        }

        Queue<GeoQueue> GeoQQ = new Queue<GeoQueue>();
        int GeoRequests = 0;
        bool GeoRunning = false;
        private void InsertGeoDataQueue(ListViewItem item, string IP, int i = 0)
        {
            GeoQueue gq = new GeoQueue(item, IP, i);
            GeoQQ.Enqueue(gq);
            //IPGeoQue.Add(gq);
            
            if (!GeoRunning)
                DoGeoDataQueue();
        }
        private void DoGeoDataQueue()
        {
            GeoRunning = true;
            while (GeoQQ.Count > 0)
            {
                if (GeoRequests < 10)
                {
                    GeoQueue gq = GeoQQ.Dequeue();
                    Thread td = new Thread(() => GetGeoData(gq.item, gq.IP, gq.geoBase));
                    td.Start();
                    tdList.Add(new ExThread(td));
                    GeoRequests++;                    
                }
            } while (GeoQQ.Count > 0);
            GeoRunning = false;
        }
        private void GetGeoData(ListViewItem item, string IP,  int i = 0)
        {
            string LocName = "";
            string Zip = "";
            string CountryCode = string.Empty;
            switch (i)
            {
                case 0: LocName = GetLocationByIP2(IP, ref Zip, ref CountryCode);
                    break;
                case 1: LocName = GetLocationByIP3(IP, ref Zip, ref CountryCode);
                    break;
                case 2: LocName = GetLocationByIP(IP, ref Zip, ref CountryCode);
                    break;
            }
            if (LocName ==  "" && i != 1)
                LocName = GetLocationByIP3(IP, ref Zip, ref CountryCode);
            if (LocName == "" && i != 2)
                LocName = GetLocationByIP(IP, ref Zip, ref CountryCode);
            if (LocName == "" && i != 0)
                LocName = GetLocationByIP2(IP, ref Zip, ref CountryCode);
            if (LocName == "")
                LocName = "[ОШИБКА]";
            Invoke(new Action(() =>
            {
                UpdateListCountry(item, LocName, Zip, CountryCode);
            }));
            GeoRequests--;
        }
#endregion

        #region Кнопки Контекст меню
        private void listView1_MouseDown(object sender, MouseEventArgs e)
        {
            ListView listGrid = sender as ListView;
            if (e.Button == MouseButtons.Right)
            {
                ListViewItem lvi = listGrid.GetItemAt(e.X, e.Y) as ListViewItem;
                if (lvi != null)
                {
                    foreach (ListViewItem item in listGrid.Items)
                    {
                        item.Selected = false;
                    }
                    lvi.Selected = true;
                }
            }
        }
        private void GetIPHost(ListViewItem item, string _IP)
        {
            IPAddress ip = IPAddress.Parse(_IP);
            string hostName = "";
            try
            {
                hostName = Dns.GetHostEntry(ip).HostName.ToString();
            }
            catch (Exception)
            {
                hostName = _IP.Replace('.', '-') + ".LazyHost";
            }
            Invoke(new Action(() =>
            {
                UpdateListHost(item, hostName);
            })); 
        }

        private void заблокироватьНа30СекундToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
                Do30SecBlock(liItem.SubItems[0].Text, liItem);
            ((ContextMenuStrip)((ToolStripMenuItem)sender).Owner).Close();
        }

        private void Do30SecBlock(string _IP, ListViewItem liItem = null, bool onlyOut = false, bool onlyIn = false)
        {
            if (_IP != "")
            {
                DoBlock(_IP, liItem, onlyOut, onlyIn);
                Thread td = new Thread(() => UnBlockIn30(_IP, liItem));
                td.Name = "UnBlock30";
                td.Start();
                tdList.Add(new ExThread(td, DateTime.Now, 30));
            }
        }
        bool ShutAll = false;
        private void UnBlockIn30(string SRemIP, ListViewItem liItem = null)
        {
            int i = 0;
            while ( i < 30 && !ShutAll)
            {
                Thread.Sleep(1000);
                i++;
            }
            DoUnBlock(SRemIP, liItem);
        }        
        bool BlockNew = false;
        private void блокироватьВсеНовыеСоединенияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tmi = (ToolStripMenuItem)sender;
            if (BlockNew)
            {
                tmi.Text = "Блокировать все новые соединения";
                BlockNew = false;
                listView1.ForeColor = SystemColors.WindowText;
            }
            else
            {
                tmi.Text = "Отключить блокировку новых соединений";
                BlockNew = true;
                listView1.ForeColor = Color.ForestGreen;
            }
        }

        private void проверитьIPПоДругойGEOIPБазеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            Thread td = new Thread(() => InsertGeoDataQueue(liItem, liItem.SubItems[0].Text, 2));
            td.Start();
            tdList.Add(new ExThread(td));
        }
        private void ipcheck2_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            Thread td = new Thread(() => InsertGeoDataQueue(liItem, liItem.SubItems[0].Text, 0));
            td.Start();
            tdList.Add(new ExThread(td));
        }
        private void ipcheck3_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            Thread td = new Thread(() => InsertGeoDataQueue(liItem, liItem.SubItems[0].Text, 1));
            td.Start();
            tdList.Add(new ExThread(td));
        }   

        private void AbuseSniffer_Resize(object sender, EventArgs e)
        {
            comboBox1.Refresh();
            cmbInterfaces.Refresh();
        }

        private void синийToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                ((IPEntry)liItem.Tag).Marked = true;
                liItem.Name = "m";
                liItem.BackColor = Color.LightSkyBlue;
            }
        }

        private void удалитьМаркерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                ((IPEntry)liItem.Tag).Marked = false;
                liItem.Name = "";
                liItem.BackColor = Color.White;
            }
        }

        private void зеленыйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                ((IPEntry)liItem.Tag).Marked = true;
                liItem.Name = "m";
                liItem.BackColor = Color.PaleGreen;
                //liItem.Hig
            }
        }

        private void оранжевыйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                ((IPEntry)liItem.Tag).Marked = true;
                liItem.Name = "m";
                liItem.BackColor = Color.Wheat;
            }
        }

        private void желтыйToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
            {
                ((IPEntry)liItem.Tag).Marked = true;
                liItem.Name = "m";
                liItem.BackColor = Color.LemonChiffon;
            }
        }
        public void ShowMe()
        {
            this.Visible = true;
            this.Activate();
        }     
        private void входящиеНа30СекундToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
                Do30SecBlock(liItem.SubItems[0].Text, liItem, true, false);
        }

        private void исходящиеНа30СекундToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem liItem = null;
            foreach (ListViewItem item in listView1.Items)
            {
                if (item.Selected)
                { liItem = item; break; }
            }
            if (liItem != null)
                Do30SecBlock(liItem.SubItems[0].Text, liItem, false, true);
        }
        #endregion
        #region Buttons and checkers
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, "PortAbuse was made by Lunatiq (aka 4seti)\r\ne-mail: podolskiyms@gmail.com\r\n\n" +
                "Thanks to MJSniffer autor from codeproject.com, i've used some code from.\r\r" +
            "Inspired by Warframe's stupid no-party-kick system.\r\n" + 
            "Special thanks to Apreex for testing.", "PortAbuse - About", MessageBoxButtons.OK, MessageBoxIcon.Information);          
        }
        private void cTM_CheckedChanged(object sender, EventArgs e)
        {
            this.TopMost = (sender as CheckBox).Checked;
        }

        private void cRem_CheckedChanged(object sender, EventArgs e)
        {
            if ((sender as CheckBox).Checked)
            {
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            }
            else
            {
                this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable;
            }
        }
        #endregion
        #region Передвижение мышкой
        private bool mDown = false;
        private Point firstPoint;
        private void AS_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                firstPoint = e.Location;
                mDown = true;
            }
        }

        private void AS_MouseMove(object sender, MouseEventArgs e)
        {
            if (mDown)
            {
                // Get the difference between the two points
                int xDiff = firstPoint.X - e.Location.X;
                int yDiff = firstPoint.Y - e.Location.Y;

                // Set the new point
                int x = this.Location.X - xDiff;
                int y = this.Location.Y - yDiff;
                this.Location = new Point(x, y);
            }
        }

        private void AS_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                mDown = false;
            }
        }

        private void AS_MouseLeave(object sender, EventArgs e)
        {
            mDown = false;
        }
        #endregion

        private void button4_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                (sender as Button).BackColor = Color.MistyRose;
                LoadProcesses(true);
                comboBox1.Text = "Выберите процесс";
                this.BringToFront();
                this.Focus();
            }
        }
    }    
}