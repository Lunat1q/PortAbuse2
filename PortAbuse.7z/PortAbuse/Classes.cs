﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Collections;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Globalization;

namespace PortAbuse
{
    public class IPEntry
    {
        public string LocIP { get; set; }
        public string RemIP { get; set; }
        public string RemHost { get; set; }
        public bool Marked { get; set; }
        public IPEntry(string _LocIP, string _RemIP, string _RemHost)
        {
            LocIP = _LocIP;
            RemIP = _RemIP;
            RemHost = _RemHost;
        }
        public IPEntry(string _LocIP, string _RemIP)
        {
            LocIP = _LocIP;
            RemIP = _RemIP;
        }
    }
    public class GeoQueue
    {
        public string IP { get; set; }
        public ListViewItem item { get; set; }
        public int geoBase { get; set; }
        public bool RequestDone { get; set; }
        public bool RequestInProgress { get; set; }
        public GeoQueue(ListViewItem _item, string _IP, int _geoBase)
        {
            IP = _IP;
            item = _item;
            geoBase = _geoBase;
            RequestInProgress = true;
            RequestDone = false;
        }
    }
    public class Item
    {
        public string Name { get; set; }
        public string InstanceName { get; set; }
        public int Value { get; set; }
        public bool isLocked { get; set; }
        public string UsedBy { get; set; }
        public Item(int _Value, string _Name, bool _Locked, string _UsedBy)
        {
            Name = _Name;
            Value = _Value;
            isLocked = _Locked;
            UsedBy = _UsedBy;
        }
        public Item(int _Value, string _Name, string _InstName)
        {
            Name = _Name;
            InstanceName = _InstName;
            Value = _Value;
        }
        public Item(int _Value, string _Name)
        {
            Name = _Name;
            Value = _Value;
        }

    }
    public class ExThread
    {
        public Thread td { get; set; }
        public DateTime tdTime { get; set; }
        public int tdLiveTime { get; set; }
        public ExThread(Thread _td, DateTime _tdTime = new DateTime(), int _tdLiveTime = 0)
        {
            td = _td;
            tdTime = _tdTime;
            tdLiveTime = _tdLiveTime;
        }        

    }
    public class HWID
    {
        private static string CpuId()
        {
            //Uses first CPU identifier available in order of preference
            //Don't get all identifiers, as it is very time consuming
            string retVal = Identifier("Win32_Processor", "UniqueId");
            if (retVal != "") return retVal;
            retVal = Identifier("Win32_Processor", "ProcessorId");
            if (retVal != "") return retVal;
            retVal = Identifier("Win32_Processor", "Name");
            if (retVal == "") //If no Name, use Manufacturer
            {
                retVal = Identifier("Win32_Processor", "Manufacturer");
            }
            //Add clock speed for extra security
            retVal += Identifier("Win32_Processor", "MaxClockSpeed");
            return retVal;
        }
        private static string Identifier(string wmiClass, string wmiProperty, string wmiMustBeTrue)
        {
            string result = "";
            System.Management.ManagementClass mc = new System.Management.ManagementClass(wmiClass);
            System.Management.ManagementObjectCollection moc = mc.GetInstances();
            foreach (System.Management.ManagementBaseObject mo in moc)
            {
                if (mo[wmiMustBeTrue].ToString() != "True") continue;
                //Only get the first one
                if (result != "") continue;
                try
                {
                    result = mo[wmiProperty].ToString();
                    break;
                }
                catch
                {
                }
            }
            return result;
        }
        private static string _fingerPrint = string.Empty;
        public static string Value()
        {
            //You don't need to generate the HWID again if it has already been generated. This is better for performance
            //Also, your HWID generally doesn't change when your computer is turned on but it can happen.
            //It's up to you if you want to keep generating a HWID or not if the function is called.
            if (string.IsNullOrEmpty(_fingerPrint))
            {
                _fingerPrint = GetHash("CPU >> " + CpuId() + "\nBIOS >> " + BiosId() + "\nBASE >> " + BaseId());
            }
            return _fingerPrint;
        }
        public static string GetHash(string s)
        {
            //Initialize a new MD5 Crypto Service Provider in order to generate a hash
            MD5 sec = new MD5CryptoServiceProvider();
            //Grab the bytes of the variable 's'
            byte[] bt = Encoding.ASCII.GetBytes(s);
            //Grab the Hexadecimal value of the MD5 hash
            return GetHexString(sec.ComputeHash(bt));
        }
        private static string GetHexString(IList<byte> bt)
        {
            string s = string.Empty;
            for (int i = 0; i < bt.Count; i++)
            {
                byte b = bt[i];
                int n = b;
                int n1 = n & 15;
                int n2 = (n >> 4) & 15;
                if (n2 > 9)
                    s += ((char)(n2 - 10 + 'A')).ToString(CultureInfo.InvariantCulture);
                else
                    s += n2.ToString(CultureInfo.InvariantCulture);
                if (n1 > 9)
                    s += ((char)(n1 - 10 + 'A')).ToString(CultureInfo.InvariantCulture);
                else
                    s += n1.ToString(CultureInfo.InvariantCulture);
                if ((i + 1) != bt.Count && (i + 1) % 2 == 0) s += "-";
            }
            return s;
        }
        private static string Identifier(string wmiClass, string wmiProperty)
        {
            string result = "";
            System.Management.ManagementClass mc = new System.Management.ManagementClass(wmiClass);
            System.Management.ManagementObjectCollection moc = mc.GetInstances();
            foreach (System.Management.ManagementBaseObject mo in moc)
            {
                //Only get the first one
                if (result != "") continue;
                try
                {
                    result = mo[wmiProperty].ToString();
                    break;
                }
                catch
                {
                }
            }
            return result;
        }
        //BIOS Identifier
        private static string BiosId()
        {
            return Identifier("Win32_BIOS", "Manufacturer") + Identifier("Win32_BIOS", "SMBIOSBIOSVersion") + Identifier("Win32_BIOS", "IdentificationCode") + Identifier("Win32_BIOS", "SerialNumber") + Identifier("Win32_BIOS", "ReleaseDate") + Identifier("Win32_BIOS", "Version");
        }
        private static string BaseId()
        {
            return Identifier("Win32_BaseBoard", "Model") + Identifier("Win32_BaseBoard", "Manufacturer") + Identifier("Win32_BaseBoard", "Name") + Identifier("Win32_BaseBoard", "SerialNumber");
        }
    }

    public class PortMaker
    {
        public static List<Port> GetNetStatPorts()
        {
            var Ports = new List<Port>();

            try
            {
                using (Process p = new Process())
                {

                    ProcessStartInfo ps = new ProcessStartInfo
                    {
                        Arguments = "/c start \"notitle\" /B \"netstat.exe\" -a -n -o",
                        FileName = "cmd.exe",
                        UseShellExecute = false,
                        CreateNoWindow = true,
                        WindowStyle = ProcessWindowStyle.Hidden,
                        RedirectStandardInput = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true
                    };

                    p.StartInfo = ps;


                    p.Start();

                    var stdOutput = p.StandardOutput;
                    var stdError = p.StandardError;

                    var content = stdOutput.ReadToEnd() + stdError.ReadToEnd();
                    var exitStatus = p.ExitCode.ToString();

                    if (exitStatus != "0")
                    {
                        // Command Errored. Handle Here If Need Be
                    }

                    //Get The Rows
                    var rows = Regex.Split(content, "\r\n");
                    Ports.AddRange(from row in rows
                        select Regex.Split(row, "\\s+")
                        into tokens
                        where tokens.Length > 4 && (tokens[1].Equals("UDP") || tokens[1].Equals("TCP"))
                        let localAddress = Regex.Replace(tokens[2], @"\[(.*?)\]", "1.1.1.1")
                        select new Port
                        {
                            protocol = localAddress.Contains("1.1.1.1") ? $"{tokens[1]}v6" : $"{tokens[1]}v4", port_number = localAddress.Split(':')[1], process_name = tokens[1] == "UDP" ? LookupProcess(Convert.ToInt16(tokens[4])) : LookupProcess(Convert.ToInt16(tokens[5]))
                        });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return Ports;
        }

        public static string LookupProcess(int pid)
        {
            string procName;
            try { procName = Process.GetProcessById(pid).ProcessName; }
            catch (Exception) { procName = "-"; }
            return procName;
        }

        // ===============================================
        // The Port Class We're Going To Create A List Of
        // ===============================================
        public class Port
        {
            public string name
            {
                get
                {
                    return string.Format("{0} ({1} port {2})", this.process_name, this.protocol, this.port_number);
                }
                set { }
            }
            public string port_number { get; set; }
            public string process_name { get; set; }
            public string protocol { get; set; }
        }
    }
}
