﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;


//DEBUG
using System.Windows.Forms;

namespace PortAbuse
{
    public class UdpEntry
    {

        #region "Main var"
        //private UdpState m_State;
        private IPEndPoint m_RemoteEndPoint;
        private IPEndPoint m_LocalEndPoint;
        private int m_ProcessID;
        #endregion
        private string m_ProcessName;
        #region "Main properties"

        public IPEndPoint RemoteEndPoint
        {
            set { m_RemoteEndPoint = value; }
            get { return m_RemoteEndPoint; }
        }

        public IPEndPoint LocalEndPoint
        {
            set { m_LocalEndPoint = value; }
            get { return m_LocalEndPoint; }
        }

        public int ProcessID
        {

            get { return m_ProcessID; }
        }

        public string ProcessName
        {
            get
            {
                if (string.IsNullOrEmpty(this.m_ProcessName))
                {
                    this.m_ProcessName = System.Diagnostics.Process.GetProcessById(this.ProcessID).ProcessName;
                }
                return this.m_ProcessName;
            }
        }
        #endregion
        public UdpEntry(UInt32 localAddress, int localPort, int processID)
        {
            //this.m_RemoteEndPoint = new IPEndPoint(remoteAddr, remotePort);
            this.m_ProcessID = processID;
            this.m_LocalEndPoint = new IPEndPoint(localAddress, localPort);
        }
    }

    public class UDP
    {
        #region "var of UDP table"
        //Const using to know what kind of connection it is (IPv4 / IPv6)
        private const Int32 AF_INET = 2;
        //Const that allow you to sort TCP table
        private const bool bOrder = true;
        //Const for GetExtendedTcpTable and GetExtendedUdpTable

        private const int dwReserved = 0;
        //Structure for retrieving data
        private enum UDP_TABLE_CLASS
        {
            UDP_TABLE_BASIC,
            UDP_TABLE_OWNER_PID,
            UDP_TABLE_OWNER_MODULE
        }

        //Structure for TCP table entries        
        private struct MIB_UDPROW_EX
        {
            public UInt32 dwLocalAddr;
            public int dwLocalPort;
            public int dwProcessId;
        }

        //List that will contains all data from each entries according to TcpEntry class
        private List<UdpEntry> m_UdpTable = new List<UdpEntry>();
        public IEnumerable<UdpEntry> UdpTable
        {
            get { return m_UdpTable; }
        }

        #endregion

        public UDP()
        {
            RetrieveUdpInfo();
        }

        [DllImport("iphlpapi.dll", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern int GetExtendedUdpTable(IntPtr pUdpTable, ref int dwOutBufLen, bool bOrder, int dwFamily, UDP_TABLE_CLASS dwClass, int dwReserved);
        //Using of TCP table (from iphlpapi.dll)
        public void RetrieveUdpInfo()
        {
            //ptr of TCP table
            IntPtr ptrTcpTable = IntPtr.Zero;
            //size of TCP table
            int outBufferLenght = 0;
            //Return values with APIs
            int ret = 0;
            //Number of table entries
            int dwNumEntries = 0;
            //ptr that define the number of data per entries
            IntPtr ptr = default(IntPtr);

            //Var for retrieving data from entries
            MIB_UDPROW_EX entry = default(MIB_UDPROW_EX);



            //getting TCp table size
            ret = GetExtendedUdpTable(ptrTcpTable, ref outBufferLenght, bOrder, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, dwReserved);

            //Allocate memory to read and retrieve information from TCP table
            try
            {
                ptrTcpTable = Marshal.AllocHGlobal(outBufferLenght);
                ret = GetExtendedUdpTable(ptrTcpTable, ref outBufferLenght, bOrder, AF_INET, UDP_TABLE_CLASS.UDP_TABLE_OWNER_PID, dwReserved);
                if (ret == 0)
                {
                    //retrieving numbers of entries
                    dwNumEntries = Marshal.ReadInt32(ptrTcpTable);
                    ptr = new IntPtr(ptrTcpTable.ToInt64() + 4);

                    for (int i = 0; i <= dwNumEntries - 1; i++)
                    {
                        //allocate memory and reading entry i
                        entry = (MIB_UDPROW_EX)Marshal.PtrToStructure(ptr, typeof(MIB_UDPROW_EX));
                        //retrieving data from entry i
                        this.m_UdpTable.Add(new UdpEntry(entry.dwLocalAddr, entry.dwLocalPort, entry.dwProcessId));
                        ptr = new IntPtr(ptr.ToInt64() + Marshal.SizeOf(typeof(MIB_UDPROW_EX)));
                    }
                }
                else
                {
                    throw new System.ComponentModel.Win32Exception(ret);
                }
            }
            catch
            {
                throw new System.ComponentModel.Win32Exception(ret);
            }
            finally
            {
                Marshal.FreeHGlobal(ptrTcpTable);
            }

        }
    }


    public class TcpEntry
    {

        #region "Main var"
        private TcpState m_State;
        private IPEndPoint m_RemoteEndPoint;
        private IPEndPoint m_LocalEndPoint;
        private int m_ProcessID;
        #endregion
        private string m_ProcessName;
        #region "Main properties"
        public TcpState state
        {
            get { return m_State; }
        }

        public IPEndPoint RemoteEndPoint
        {
            get { return m_RemoteEndPoint; }
        }

        public IPEndPoint LocalEndPoint
        {
            get { return m_LocalEndPoint; }
        }

        public int ProcessID
        {
            get { return m_ProcessID; }
        }

        public string ProcessName
        {
            get
            {
                if (string.IsNullOrEmpty(this.m_ProcessName))
                {
                    this.m_ProcessName = System.Diagnostics.Process.GetProcessById(this.ProcessID).ProcessName;
                }
                return this.m_ProcessName;
            }
        }
        #endregion
        public TcpEntry(TcpState state, UInt32 remoteAddr, int remotePort, UInt32 localAddress, int localPort, int processID)
        {
            this.m_State = state;
            this.m_RemoteEndPoint = new IPEndPoint(remoteAddr, remotePort);
            this.m_ProcessID = processID;
            this.m_LocalEndPoint = new IPEndPoint(localAddress, localPort);
        }
    }
    public class TCP
    {

        #region "var of TCP table"
        //Const using to know what kind of connection it is (IPv4 / IPv6)
        private const Int32 AF_INET = 2;
        //Const that allow you to sort TCP table
        private const bool bOrder = true;
        //Const for GetExtendedTcpTable and GetExtendedUdpTable

        private const int dwReserved = 0;
        //Structure for retrieving data
        private enum TCP_TABLE_CLASS
        {
            TCP_TABLE_BASIC_LISTENER,
            TCP_TABLE_BASIC_CONNECTIONS,
            TCP_TABLE_BASIC_ALL,
            TCP_TABLE_OWNER_PID_LISTENER,
            TCP_TABLE_OWNER_PID_CONNECTIONS,
            TCP_TABLE_OWNER_PID_ALL,
            TCP_TABLE_OWNER_MODULE_LISTENER,
            TCP_TABLE_OWNER_MODULE_CONNECTIONS,
            TCP_TABLE_OWNER_MODULE_ALL
        }

        //Structure for TCP table entries
        private struct MIB_TCPROW_EX
        {
            public TcpState dwState;
            public UInt32 dwLocalAddr;
            public int dwLocalPort;
            public UInt32 dwRemoteAddr;
            public int dwRemotePort;
            public int dwProcessId;
        }

        //List that will contains all data from each entries according to TcpEntry class
        private List<TcpEntry> m_TcpTable = new List<TcpEntry>();
        public IEnumerable<TcpEntry> TcpTable
        {
            get { return m_TcpTable; }
        }

        #endregion

        public TCP()
        {
            RetrieveTcpInfo();
        }
        [DllImport("iphlpapi.dll", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
        private static extern int GetExtendedTcpTable(IntPtr pTcpTable, ref int dwOutBufLen, bool bOrder, int dwFamily, TCP_TABLE_CLASS dwClass, int dwReserved);
        //Using of TCP table (from iphlpapi.dll)
        public void RetrieveTcpInfo()
        {
            //ptr of TCP table
            IntPtr ptrTcpTable = IntPtr.Zero;
            //size of TCP table
            int outBufferLenght = 0;
            //Return values with APIs
            int ret = 0;
            //Number of table entries
            int dwNumEntries = 0;
            //ptr that define the number of data per entries
            IntPtr ptr = default(IntPtr);
            //Var for retrieving data from entries
            MIB_TCPROW_EX entry = new MIB_TCPROW_EX();



            //getting TCp table size
            ret = GetExtendedTcpTable(ptrTcpTable, ref outBufferLenght, bOrder, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, dwReserved);
            int iStructSize = Marshal.SizeOf(entry);
            //Allocate memory to read and retrieve information from TCP table
            try
            {
                ptrTcpTable = Marshal.AllocHGlobal(outBufferLenght);
                ret = GetExtendedTcpTable(ptrTcpTable, ref outBufferLenght, bOrder, AF_INET, TCP_TABLE_CLASS.TCP_TABLE_OWNER_PID_ALL, dwReserved);
                if (ret == 0)
                {
                    //retrieving numbers of entries
                    dwNumEntries = Marshal.ReadInt32(ptrTcpTable);
                    ptr = new IntPtr(ptrTcpTable.ToInt64() + 4);

                    MIB_TCPROW_EX[] entryArr = new MIB_TCPROW_EX[dwNumEntries];
                    for (int i = 0; i <= dwNumEntries - 1; i++)
                    {
                        //allocate memory and reading entry i
                        entryArr[i] = (MIB_TCPROW_EX)Marshal.PtrToStructure(ptr, typeof(MIB_TCPROW_EX));
                        ptr = new IntPtr(ptr.ToInt64() + iStructSize);
                    }
                    for (int i = 0; i <= dwNumEntries - 1; i++)
                    {
                        try
                        {
                            //retrieving data from entry i
                            this.m_TcpTable.Add(new TcpEntry(entryArr[i].dwState, entryArr[i].dwRemoteAddr, entryArr[i].dwRemotePort, entryArr[i].dwLocalAddr, entryArr[i].dwLocalPort, entryArr[i].dwProcessId));
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                    }
                }
                else
                {
                    throw new System.ComponentModel.Win32Exception(ret);
                }
            }
            catch
            {
                throw new System.ComponentModel.Win32Exception(ret);
            }
            finally
            {
                Marshal.FreeHGlobal(ptrTcpTable);
            }

        }
    }
}

