﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;
using System.Security.Principal;

namespace PortAbuse
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            var wi = WindowsIdentity.GetCurrent();
            var wp = new WindowsPrincipal(wi);
 
            bool runAsAdmin = wp.IsInRole(WindowsBuiltInRole.Administrator);

            if (!IsAdministrator())
            {
                // It is not possible to launch a ClickOnce app as administrator directly,
                // so instead we launch the app as administrator in a new process.
                var processInfo = new ProcessStartInfo(Assembly.GetExecutingAssembly().CodeBase);

                // The following properties run the new process as administrator
                processInfo.UseShellExecute = true;
                string args = string.Empty;
                string[] _args = Environment.GetCommandLineArgs();
                for (int i = 0; i < _args.Length; i++)
			    {
                    if (i > 0)
                        args += _args[i] + " ";			 
			    }
                args.Trim();
                processInfo.Arguments = args;
                processInfo.Verb = "runas";

                // Start the new process
                try
                {
                    Process.Start(processInfo);
                }
                catch (Exception)
                {
                    // The user did not allow the application to run as administrator
                    MessageBox.Show("Запустите программу от имени администратора!");
                }

                // Shut down the current process
                Application.Exit();
            }
            else
            {
                String[] arguments = Environment.GetCommandLineArgs();
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                if (arguments.Length > 1)
                {
                    if (arguments.Length == 2)
                        Application.Run(new AbuseSniffer(arguments[1]));
                    else if ((arguments.Length > 2))
                        Application.Run(new AbuseSniffer(arguments[1], arguments[2]));
                }
                else
                    Application.Run(new AbuseSniffer());
            }
        }
        public static bool IsAdministrator()
        {
            return (new WindowsPrincipal(WindowsIdentity.GetCurrent()))
                    .IsInRole(WindowsBuiltInRole.Administrator);
        } 
        //public static void CheckPC(AbuseSniffer frm)
        //{
        //    bool AcceptPC = false;
        //    string[] HWIDWhiteList = new string[] { "20E0-4436-2B27-A3E9-C15E-1257-AB5B-25E6", "F0F7-DD08-539C-A919-194E-D739-D40D-E441", "15BC-2C3B-2FB6-2566-0714-D638-4E01-305B" };
        //    string _HWID = HWID.Value();
        //    for (int i = 0; i < HWIDWhiteList.Length; i++)
        //    {
        //        if (HWIDWhiteList[i] == _HWID)
        //        {
        //            AcceptPC = true;
        //            break;
        //        }
        //    }
        //    frm.Invoke(new Action(() =>
        //    {
        //        frm.SetAcceptPC(AcceptPC);
        //    })); 
        //}
    }
}
